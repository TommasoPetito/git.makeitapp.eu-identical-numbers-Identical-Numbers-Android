package android.support.v4.net;

import android.annotation.TargetApi;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.support.annotation.RequiresApi;
import com.companyname.IDENTICAL_NUMBERS_cbeta_890.nVidiaShieldDevice;
import com.yoyogames.runner.RunnerJNILib;
import io.fabric.sdk.android.services.common.CommonUtils;
import io.fabric.sdk.android.services.common.ResponseParser;
import io.fabric.sdk.android.services.settings.SettingsJsonConstants;

@TargetApi(13)
@RequiresApi(13)
class ConnectivityManagerCompatHoneycombMR2 {
    ConnectivityManagerCompatHoneycombMR2() {
    }

    public static boolean isActiveNetworkMetered(ConnectivityManager cm) {
        NetworkInfo info = cm.getActiveNetworkInfo();
        if (info == null) {
            return true;
        }
        switch (info.getType()) {
            case ResponseParser.ResponseActionDiscard /*0*/:
            case CommonUtils.DEVICE_STATE_JAILBROKEN /*2*/:
            case RunnerJNILib.eOF_AchievementSendFail /*3*/:
            case SettingsJsonConstants.SETTINGS_MAX_COMPLETE_SESSIONS_COUNT_DEFAULT /*4*/:
            case RunnerJNILib.eOF_HighScoreSendFail /*5*/:
            case nVidiaShieldDevice.AXIS_TOOL_MAJOR /*6*/:
                return true;
            case SettingsJsonConstants.ANALYTICS_SAMPLING_RATE_DEFAULT /*1*/:
            case nVidiaShieldDevice.AXIS_TOOL_MINOR /*7*/:
            case nVidiaShieldDevice.AXIS_VSCROLL /*9*/:
                return false;
            default:
                return true;
        }
    }
}
