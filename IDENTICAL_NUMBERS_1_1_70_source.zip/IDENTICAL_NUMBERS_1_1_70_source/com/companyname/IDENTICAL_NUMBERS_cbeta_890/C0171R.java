package com.companyname.IDENTICAL_NUMBERS_cbeta_890;

/* renamed from: com.companyname.IDENTICAL_NUMBERS_cbeta_890.R */
public final class C0171R {

    /* renamed from: com.companyname.IDENTICAL_NUMBERS_cbeta_890.R.attr */
    public static final class attr {
    }

    /* renamed from: com.companyname.IDENTICAL_NUMBERS_cbeta_890.R.drawable */
    public static final class drawable {
        public static final int icon = 2130837504;
    }

    /* renamed from: com.companyname.IDENTICAL_NUMBERS_cbeta_890.R.id */
    public static final class id {
        public static final int ad = 2131099666;
        public static final int approveCellular = 2131099659;
        public static final int buttonRow = 2131099662;
        public static final int cancelButton = 2131099658;
        public static final int demogl = 2131099665;
        public static final int downloaderDashboard = 2131099650;
        public static final int downloaderDashboardHoriz = 2131099656;
        public static final int password = 2131099670;
        public static final int password_view = 2131099669;
        public static final int pauseButton = 2131099657;
        public static final int progressAsFraction = 2131099651;
        public static final int progressAsPercentage = 2131099652;
        public static final int progressAverageSpeed = 2131099654;
        public static final int progressBar = 2131099653;
        public static final int progressTimeRemaining = 2131099655;
        public static final int resumeOverCellular = 2131099663;
        public static final int statusText = 2131099649;
        public static final int textPausedParagraph1 = 2131099660;
        public static final int textPausedParagraph2 = 2131099661;
        public static final int title_bar = 2131099648;
        public static final int username = 2131099668;
        public static final int username_view = 2131099667;
        public static final int wifiSettingsButton = 2131099664;
    }

    /* renamed from: com.companyname.IDENTICAL_NUMBERS_cbeta_890.R.layout */
    public static final class layout {
        public static final int download = 2130903040;
        public static final int main = 2130903041;
        public static final int userpasslayout = 2130903042;
    }

    /* renamed from: com.companyname.IDENTICAL_NUMBERS_cbeta_890.R.string */
    public static final class string {
        public static final int app_id = 2131034112;
        public static final int app_name = 2131034113;
        public static final int banner_desc = 2131034114;
        public static final int billing_failed_message = 2131034115;
        public static final int billing_failed_title = 2131034116;
        public static final int billing_not_supported_message = 2131034117;
        public static final int billing_not_supported_title = 2131034118;
        public static final int cannot_connect_message = 2131034119;
        public static final int cannot_connect_title = 2131034120;
        public static final int com_crashlytics_android_build_id = 2131034121;
        public static final int help_url = 2131034122;
        public static final int learn_more = 2131034123;
        public static final int license_fail = 2131034124;
        public static final int menu_exit = 2131034125;
        public static final int menu_settings = 2131034126;
        public static final int restoring_transactions = 2131034127;
        public static final int text_button_cancel = 2131034128;
        public static final int text_button_pause = 2131034129;
        public static final int text_button_resume = 2131034130;
        public static final int text_button_resume_cellular = 2131034131;
        public static final int text_button_wifi_settings = 2131034132;
        public static final int text_paused_cellular = 2131034133;
        public static final int text_paused_cellular_2 = 2131034134;
        public static final int xperiaplayoptimized_content = 2131034135;
    }

    /* renamed from: com.companyname.IDENTICAL_NUMBERS_cbeta_890.R.xml */
    public static final class xml {
        public static final int preferences = 2130968576;
    }
}
