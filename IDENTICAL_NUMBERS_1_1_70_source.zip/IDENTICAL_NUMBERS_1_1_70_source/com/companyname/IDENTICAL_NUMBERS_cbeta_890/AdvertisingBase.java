package com.companyname.IDENTICAL_NUMBERS_cbeta_890;

import android.app.Activity;
import android.util.Log;
import android.view.Display;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AbsoluteLayout.LayoutParams;
import com.companyname.IDENTICAL_NUMBERS_cbeta_890.IAdvertising.AdTypes;
import com.yoyogames.runner.RunnerJNILib;
import io.fabric.sdk.android.services.common.CommonUtils;
import io.fabric.sdk.android.services.common.ResponseParser;
import io.fabric.sdk.android.services.settings.SettingsJsonConstants;

class AdvertisingBase implements IAdvertising {
    public Activity m_activity;
    public String[] m_adDefinitions;
    public AdTypes[] m_adTypes;
    public boolean m_usetestads;
    public View m_view;
    public ViewGroup m_viewGroup;

    /* renamed from: com.companyname.IDENTICAL_NUMBERS_cbeta_890.AdvertisingBase.1 */
    class C01581 implements Runnable {
        final /* synthetic */ int val$h;
        final /* synthetic */ IAdvertising val$iad;
        final /* synthetic */ int val$index;
        final /* synthetic */ View val$view;
        final /* synthetic */ int val$w;
        final /* synthetic */ int val$x;
        final /* synthetic */ int val$y;

        C01581(int i, View view, int i2, int i3, int i4, int i5, IAdvertising iAdvertising) {
            this.val$index = i;
            this.val$view = view;
            this.val$w = i2;
            this.val$h = i3;
            this.val$x = i4;
            this.val$y = i5;
            this.val$iad = iAdvertising;
        }

        public void run() {
            Log.i("yoyo", "adding view for index " + this.val$index);
            if (this.val$view.getParent() == null) {
                AdvertisingBase.this.m_viewGroup.addView(this.val$view);
            }
            this.val$view.setLayoutParams(new LayoutParams(this.val$w, this.val$h, this.val$x, this.val$y));
            if (AdvertisingBase.this.m_usetestads) {
                this.val$view.setBackgroundColor(-16776961);
            } else {
                this.val$view.setBackgroundColor(0);
            }
            this.val$view.requestLayout();
            this.val$iad.refresh(this.val$index);
            this.val$view.setVisibility(0);
        }
    }

    /* renamed from: com.companyname.IDENTICAL_NUMBERS_cbeta_890.AdvertisingBase.2 */
    class C01592 implements Runnable {
        final /* synthetic */ int val$h;
        final /* synthetic */ View val$view;
        final /* synthetic */ int val$w;
        final /* synthetic */ int val$x;
        final /* synthetic */ int val$y;

        C01592(int i, int i2, int i3, int i4, View view) {
            this.val$w = i;
            this.val$h = i2;
            this.val$x = i3;
            this.val$y = i4;
            this.val$view = view;
        }

        public void run() {
            this.val$view.setLayoutParams(new LayoutParams(this.val$w, this.val$h, this.val$x, this.val$y));
            if (AdvertisingBase.this.m_usetestads) {
                this.val$view.setBackgroundColor(-16776961);
            } else {
                this.val$view.setBackgroundColor(0);
            }
            this.val$view.requestLayout();
            this.val$view.setVisibility(0);
        }
    }

    /* renamed from: com.companyname.IDENTICAL_NUMBERS_cbeta_890.AdvertisingBase.3 */
    class C01603 implements Runnable {
        final /* synthetic */ View val$view;

        C01603(View view) {
            this.val$view = view;
        }

        public void run() {
            this.val$view.setVisibility(8);
            if (this.val$view.getParent() != null) {
                AdvertisingBase.this.m_viewGroup.removeView(this.val$view);
            }
        }
    }

    /* renamed from: com.companyname.IDENTICAL_NUMBERS_cbeta_890.AdvertisingBase.4 */
    static /* synthetic */ class C01614 {
        static final /* synthetic */ int[] f6x48759aec;

        static {
            f6x48759aec = new int[AdTypes.values().length];
            try {
                f6x48759aec[AdTypes.BANNER.ordinal()] = 1;
            } catch (NoSuchFieldError e) {
            }
            try {
                f6x48759aec[AdTypes.MRECT.ordinal()] = 2;
            } catch (NoSuchFieldError e2) {
            }
            try {
                f6x48759aec[AdTypes.FULL_BANNER.ordinal()] = 3;
            } catch (NoSuchFieldError e3) {
            }
            try {
                f6x48759aec[AdTypes.LEADERBOARD.ordinal()] = 4;
            } catch (NoSuchFieldError e4) {
            }
            try {
                f6x48759aec[AdTypes.SKYSCRAPER.ordinal()] = 5;
            } catch (NoSuchFieldError e5) {
            }
        }
    }

    public AdvertisingBase(Activity _activity, ViewGroup _viewGroup, boolean _usetestads) {
        this.m_activity = _activity;
        this.m_viewGroup = _viewGroup;
        this.m_adDefinitions = new String[10];
        this.m_adTypes = new AdTypes[10];
        this.m_view = null;
        this.m_usetestads = _usetestads;
    }

    public static AdTypes ConvertToAdType(int _type) {
        AdTypes ret = AdTypes.BANNER;
        switch (_type) {
            case ResponseParser.ResponseActionDiscard /*0*/:
                return AdTypes.BANNER;
            case SettingsJsonConstants.ANALYTICS_SAMPLING_RATE_DEFAULT /*1*/:
                return AdTypes.MRECT;
            case CommonUtils.DEVICE_STATE_JAILBROKEN /*2*/:
                return AdTypes.FULL_BANNER;
            case RunnerJNILib.eOF_AchievementSendFail /*3*/:
                return AdTypes.LEADERBOARD;
            case SettingsJsonConstants.SETTINGS_MAX_COMPLETE_SESSIONS_COUNT_DEFAULT /*4*/:
                return AdTypes.SKYSCRAPER;
            case RunnerJNILib.eOF_HighScoreSendFail /*5*/:
                return AdTypes.INTERSTITIAL;
            default:
                return ret;
        }
    }

    public void on_iap_success(String _ident) {
    }

    public void on_iap_cancelled(String _ident) {
    }

    public void on_iap_failed(String _ident) {
    }

    public int getAdWidth(AdTypes _type) {
        float density = this.m_activity.getResources().getDisplayMetrics().density;
        float ret = 0.0f;
        if (_type != null) {
            switch (C01614.f6x48759aec[_type.ordinal()]) {
                case SettingsJsonConstants.ANALYTICS_SAMPLING_RATE_DEFAULT /*1*/:
                    ret = 320.0f;
                    break;
                case CommonUtils.DEVICE_STATE_JAILBROKEN /*2*/:
                    ret = 300.0f;
                    break;
                case RunnerJNILib.eOF_AchievementSendFail /*3*/:
                    ret = 468.0f;
                    break;
                case SettingsJsonConstants.SETTINGS_MAX_COMPLETE_SESSIONS_COUNT_DEFAULT /*4*/:
                    ret = 728.0f;
                    break;
                case RunnerJNILib.eOF_HighScoreSendFail /*5*/:
                    ret = 120.0f;
                    break;
            }
        }
        return (int) (ret * density);
    }

    public int getAdHeight(AdTypes _type) {
        float density = this.m_activity.getResources().getDisplayMetrics().density;
        float ret = 0.0f;
        if (_type != null) {
            switch (C01614.f6x48759aec[_type.ordinal()]) {
                case SettingsJsonConstants.ANALYTICS_SAMPLING_RATE_DEFAULT /*1*/:
                    ret = 53.0f;
                    break;
                case CommonUtils.DEVICE_STATE_JAILBROKEN /*2*/:
                    ret = 250.0f;
                    break;
                case RunnerJNILib.eOF_AchievementSendFail /*3*/:
                    ret = 60.0f;
                    break;
                case SettingsJsonConstants.SETTINGS_MAX_COMPLETE_SESSIONS_COUNT_DEFAULT /*4*/:
                    ret = 90.0f;
                    break;
                case RunnerJNILib.eOF_HighScoreSendFail /*5*/:
                    ret = 600.0f;
                    break;
            }
        }
        return (int) (ret * density);
    }

    public int getAdDisplayWidth(int _index) {
        if (_index < 0 || _index >= this.m_adTypes.length) {
            return 0;
        }
        int w = getAdWidth(this.m_adTypes[_index]);
        Display d = this.m_activity.getWindowManager().getDefaultDisplay();
        return (d.getWidth() * w) / RunnerJNILib.getGuiWidth();
    }

    public void onResume() {
    }

    public void onPause() {
    }

    public int getAdDisplayHeight(int _index) {
        if (_index < 0 || _index >= this.m_adTypes.length) {
            return 0;
        }
        int h = getAdHeight(this.m_adTypes[_index]);
        Display d = this.m_activity.getWindowManager().getDefaultDisplay();
        return (d.getHeight() * h) / RunnerJNILib.getGuiHeight();
    }

    public void enable_interstitial(int _index) {
        Log.i("yoyo", "Interstitials not supported for this provider");
    }

    public void pc_badge_add(int _x, int _y, int _width, int _height, String _ident) {
    }

    public void pc_badge_move(int _x, int _y, int _width, int _height) {
    }

    public void pc_badge_hide() {
    }

    public void pc_badge_update() {
    }

    public void reward_callback(int funcid) {
    }

    public void enable(int _x, int _y, int _index) {
        if (this.m_adTypes[_index] == AdTypes.INTERSTITIAL) {
            enable_interstitial(_index);
            return;
        }
        setView(_index);
        View view = this.m_view;
        AdvertisingBase iad = this;
        int x = _x;
        int y = _y;
        int w = getAdWidth(this.m_adTypes[_index]);
        int h = getAdHeight(this.m_adTypes[_index]);
        int index = _index;
        if (w == 0 || h == 0) {
            Log.i("yoyo", "error enabling ad with index " + _index);
        } else {
            RunnerActivity.ViewHandler.post(new C01581(index, view, w, h, x, y, iad));
        }
    }

    public void move(int _x, int _y, int _index) {
        setView(_index);
        View view = this.m_view;
        int x = _x;
        int y = _y;
        RunnerActivity.ViewHandler.post(new C01592(getAdWidth(this.m_adTypes[_index]), getAdHeight(this.m_adTypes[_index]), x, y, view));
    }

    public void event(String _ident) {
    }

    public void event_preload(String _ident) {
    }

    public void disable(int _index) {
        setView(_index);
        if (this.m_view != null) {
            RunnerActivity.ViewHandler.post(new C01603(this.m_view));
        }
    }

    public void setup(String _userid) {
    }

    public boolean interstitial_available() {
        return false;
    }

    public boolean interstitial_display() {
        return false;
    }

    public boolean engagement_available() {
        return false;
    }

    public boolean engagement_active() {
        return false;
    }

    public void engagement_launch() {
    }

    public void setView(int _index) {
    }

    public void refresh(int _index) {
    }

    public void define(int _index, String _key, AdTypes _type) {
        if (_index >= 0 && _index < this.m_adDefinitions.length) {
            this.m_adDefinitions[_index] = _key;
            this.m_adTypes[_index] = _type;
        }
    }

    public void pause() {
    }

    public void resume() {
    }
}
