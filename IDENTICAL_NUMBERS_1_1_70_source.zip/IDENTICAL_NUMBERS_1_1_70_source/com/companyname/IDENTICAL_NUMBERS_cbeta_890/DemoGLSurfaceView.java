package com.companyname.IDENTICAL_NUMBERS_cbeta_890;

import android.content.Context;
import android.opengl.GLSurfaceView;
import android.opengl.GLSurfaceView.EGLConfigChooser;
import android.os.Build.VERSION;
import android.os.Handler;
import android.support.v4.view.MotionEventCompat;
import android.util.AttributeSet;
import android.util.Log;
import android.view.MotionEvent;
import com.yoyogames.runner.RunnerJNILib;
import io.fabric.sdk.android.services.settings.SettingsJsonConstants;
import java.util.Locale;
import javax.microedition.khronos.egl.EGL10;
import javax.microedition.khronos.egl.EGLConfig;
import javax.microedition.khronos.egl.EGLContext;
import javax.microedition.khronos.egl.EGLDisplay;
import javax.microedition.khronos.egl.EGLSurface;
import javax.microedition.khronos.opengles.GL;
import javax.microedition.khronos.opengles.GL10;

public class DemoGLSurfaceView extends GLSurfaceView implements EGLConfigChooser {
    public static int m_usingGL2;
    public DemoRenderer mRenderer;
    private Context m_context;
    private int m_fpsTime;
    int m_prev;
    private Handler m_refreshHandler;
    private Runnable m_refreshTick;

    /* renamed from: com.companyname.IDENTICAL_NUMBERS_cbeta_890.DemoGLSurfaceView.1 */
    class C01621 implements Runnable {
        C01621() {
        }

        public void run() {
            DemoGLSurfaceView.this.m_refreshHandler.postDelayed(this, (long) DemoGLSurfaceView.this.m_fpsTime);
            if (DemoGLSurfaceView.this.mRenderer.m_renderCount <= 0) {
                DemoRenderer demoRenderer = DemoGLSurfaceView.this.mRenderer;
                demoRenderer.m_renderCount++;
                DemoGLSurfaceView.this.requestRender();
            }
        }
    }

    static {
        m_usingGL2 = 0;
    }

    public EGLConfig chooseConfig(EGL10 egl, EGLDisplay display) {
        Log.i("yoyo", "chooseConfig");
        int EGL_OPENGL_ES2_BIT = 4;
        int[] num_config = new int[]{0};
        int[] mMinConfigSpec = new int[11];
        mMinConfigSpec[0] = 12324;
        mMinConfigSpec[1] = 5;
        mMinConfigSpec[2] = 12323;
        mMinConfigSpec[3] = 6;
        mMinConfigSpec[4] = 12322;
        mMinConfigSpec[5] = 5;
        mMinConfigSpec[6] = 12325;
        mMinConfigSpec[7] = 16;
        mMinConfigSpec[8] = 12352;
        if (m_usingGL2 == 0) {
            EGL_OPENGL_ES2_BIT = 1;
        }
        mMinConfigSpec[9] = EGL_OPENGL_ES2_BIT;
        mMinConfigSpec[10] = 12344;
        egl.eglChooseConfig(display, mMinConfigSpec, null, 0, num_config);
        int eglError = egl.eglGetError();
        if (12288 != eglError) {
            Log.i("yoyo", "Error choosing original minspec EGL config : " + eglError);
            int[] lowMinConfigSpec = new int[]{12324, 5, 12323, 6, 12322, 5, 12325, 16, 12344};
            egl.eglChooseConfig(display, lowMinConfigSpec, null, 0, num_config);
            eglError = egl.eglGetError();
            if (12288 != eglError) {
                Log.i("yoyo", "Still an error choosing cutdown minspec EGL config : " + eglError);
                throw new IllegalArgumentException("No EGL configs match our minimum required spec");
            }
            mMinConfigSpec = lowMinConfigSpec;
        }
        if (num_config[0] <= 0) {
            throw new IllegalArgumentException("No EGL configs match our minimum required spec");
        }
        EGLSurface surf;
        RunnerActivity runnerActivity;
        int[] configSortKeys;
        int i;
        boolean sorted;
        int validConfig;
        int numConfigs = num_config[0];
        EGLConfig[] configs = new EGLConfig[numConfigs];
        egl.eglChooseConfig(display, mMinConfigSpec, configs, numConfigs, num_config);
        eglError = egl.eglGetError();
        if (12288 != eglError) {
            Log.i("yoyo", "Error fetching EGL configs : " + eglError);
        }
        int[] attrib_list = new int[3];
        attrib_list[0] = 12440;
        attrib_list[1] = m_usingGL2 != 0 ? 2 : 1;
        attrib_list[2] = 12344;
        boolean z = true;
        EGLContext testContext = egl.eglCreateContext(display, configs[0], EGL10.EGL_NO_CONTEXT, attrib_list);
        eglError = egl.eglGetError();
        if (12292 == eglError) {
            Log.i("yoyo", "Bad Attrib on eglCreateContext... using empty attrib_list");
            attrib_list = null;
            testContext = egl.eglCreateContext(display, configs[0], EGL10.EGL_NO_CONTEXT, null);
            eglError = egl.eglGetError();
        }
        if (eglError != 12288 || testContext == null || testContext == EGL10.EGL_NO_CONTEXT) {
            Log.i("yoyo", "Could not create test " + (m_usingGL2 != 0 ? "GL2" : "GL1") + "context. EGLError: " + eglError);
        } else {
            surf = egl.eglCreateWindowSurface(display, configs[0], getHolder(), null);
            if (surf != null && surf != EGL10.EGL_NO_SURFACE) {
                if (egl.eglMakeCurrent(display, surf, surf, testContext)) {
                    GL gl = testContext.getGL();
                    if (gl instanceof GL10) {
                        String extString = ((GL10) gl).glGetString(7939);
                        Log.i("yoyo", "OpenGL ES Extensions : " + extString);
                        if (extString.contains("GL_OES_rgb8_rgba8")) {
                            Log.i("yoyo", "Device supports 32bit display formats");
                            z = false;
                        }
                    }
                    egl.eglMakeCurrent(display, EGL10.EGL_NO_SURFACE, EGL10.EGL_NO_SURFACE, EGL10.EGL_NO_CONTEXT);
                } else {
                    Log.i("EGLHelper", "eglMakeCurrent broke");
                }
                egl.eglDestroySurface(display, surf);
            } else if (egl.eglGetError() != 12288) {
                Log.i("yoyo", "window surface can't be created");
            }
            egl.eglDestroyContext(display, testContext);
        }
        if (this.m_context != null && (this.m_context instanceof RunnerActivity)) {
            runnerActivity = (RunnerActivity) this.m_context;
            if (RunnerActivity.mYYPrefs != null) {
                runnerActivity = (RunnerActivity) this.m_context;
                if (RunnerActivity.mYYPrefs.getInt("YYUse24Bit") == 1) {
                    Log.i("yoyo", "24 bit colour depth allowed");
                } else {
                    Log.i("yoyo", "16 bit colour depth forced");
                    z = true;
                }
                configSortKeys = new int[numConfigs];
                for (i = 0; i < numConfigs; i++) {
                    configSortKeys[i] = generateConfigSortKey(egl, display, configs[i], z);
                }
                sorted = false;
                while (!sorted) {
                    sorted = true;
                    for (i = 0; i < numConfigs - 1; i++) {
                        if (configSortKeys[i] < configSortKeys[i + 1]) {
                            sorted = false;
                            EGLConfig tempConfig = configs[i];
                            configs[i] = configs[i + 1];
                            configs[i + 1] = tempConfig;
                            int tempSortKey = configSortKeys[i];
                            configSortKeys[i] = configSortKeys[i + 1];
                            configSortKeys[i + 1] = tempSortKey;
                        }
                    }
                }
                validConfig = -1;
                for (i = 0; i < numConfigs; i++) {
                    Log.i("yoyo", "Trying EGL config : " + printConfig(egl, display, configs[i]));
                    EGLContext tempContext = egl.eglCreateContext(display, configs[i], EGL10.EGL_NO_CONTEXT, attrib_list);
                    eglError = egl.eglGetError();
                    if (eglError == 12288 || tempContext == null || tempContext == EGL10.EGL_NO_CONTEXT) {
                        Log.i("yoyo", "Selected EGL config failed: " + eglError);
                    } else {
                        surf = egl.eglCreateWindowSurface(display, configs[i], getHolder(), null);
                        if (surf != null && surf != EGL10.EGL_NO_SURFACE) {
                            if (egl.eglMakeCurrent(display, surf, surf, tempContext)) {
                                Log.i("yoyo", "Selected EGL config working");
                                egl.eglMakeCurrent(display, EGL10.EGL_NO_SURFACE, EGL10.EGL_NO_SURFACE, EGL10.EGL_NO_CONTEXT);
                                validConfig = i;
                            } else {
                                Log.i("yoyo", "eglMakeCurrent failed - can't use this mode");
                            }
                            egl.eglDestroySurface(display, surf);
                        } else if (egl.eglGetError() != 12288) {
                            Log.i("yoyo", "Surface can't be created - can't use this mode");
                        }
                        egl.eglDestroyContext(display, tempContext);
                    }
                    if (validConfig == -1) {
                        break;
                    }
                }
                if (validConfig == -1) {
                    return configs[validConfig];
                }
                throw new IllegalArgumentException("No valid EGL configs match our minimum required spec");
            }
        }
        if (this.m_context == null) {
            Log.i("yoyo", "Context NULL");
        }
        if (!(this.m_context instanceof RunnerActivity)) {
            Log.i("yoyo", "Context not RunnerActivity");
        }
        runnerActivity = (RunnerActivity) this.m_context;
        if (RunnerActivity.mYYPrefs == null) {
            Log.i("yoyo", "mYYPrefs null");
        }
        configSortKeys = new int[numConfigs];
        for (i = 0; i < numConfigs; i++) {
            configSortKeys[i] = generateConfigSortKey(egl, display, configs[i], z);
        }
        sorted = false;
        while (!sorted) {
            sorted = true;
            for (i = 0; i < numConfigs - 1; i++) {
                if (configSortKeys[i] < configSortKeys[i + 1]) {
                    sorted = false;
                    EGLConfig tempConfig2 = configs[i];
                    configs[i] = configs[i + 1];
                    configs[i + 1] = tempConfig2;
                    int tempSortKey2 = configSortKeys[i];
                    configSortKeys[i] = configSortKeys[i + 1];
                    configSortKeys[i + 1] = tempSortKey2;
                }
            }
        }
        validConfig = -1;
        while (i < numConfigs) {
            Log.i("yoyo", "Trying EGL config : " + printConfig(egl, display, configs[i]));
            EGLContext tempContext2 = egl.eglCreateContext(display, configs[i], EGL10.EGL_NO_CONTEXT, attrib_list);
            eglError = egl.eglGetError();
            if (eglError == 12288) {
            }
            Log.i("yoyo", "Selected EGL config failed: " + eglError);
            if (validConfig == -1) {
            } else {
                break;
                if (validConfig == -1) {
                    return configs[validConfig];
                }
                throw new IllegalArgumentException("No valid EGL configs match our minimum required spec");
            }
        }
        if (validConfig == -1) {
            return configs[validConfig];
        }
        throw new IllegalArgumentException("No valid EGL configs match our minimum required spec");
    }

    private String printConfig(EGL10 egl, EGLDisplay display, EGLConfig config) {
        int id = findConfigAttrib(egl, display, config, 12328, 0);
        int r = findConfigAttrib(egl, display, config, 12324, 0);
        int g = findConfigAttrib(egl, display, config, 12323, 0);
        int b = findConfigAttrib(egl, display, config, 12322, 0);
        int a = findConfigAttrib(egl, display, config, 12321, 0);
        int d = findConfigAttrib(egl, display, config, 12325, 0);
        int s = findConfigAttrib(egl, display, config, 12326, 0);
        return String.format(Locale.US, "EGLConfig %d: rgba=%d%d%d%d depth=%d stencil=%d", new Object[]{Integer.valueOf(id), Integer.valueOf(r), Integer.valueOf(g), Integer.valueOf(b), Integer.valueOf(a), Integer.valueOf(d), Integer.valueOf(s)}) + " EGL_ALPHA_MASK_SIZE=" + findConfigAttrib(egl, display, config, 12350, 0) + " EGL_BUFFER_SIZE=" + findConfigAttrib(egl, display, config, 12320, 0) + " EGL_COLOR_BUFFER_TYPE=" + findConfigAttrib(egl, display, config, 12351, 0) + String.format(Locale.US, " EGL_CONFIG_CAVEAT=0x%04x", new Object[]{Integer.valueOf(findConfigAttrib(egl, display, config, 12327, 0))}) + " EGL_LEVEL=" + findConfigAttrib(egl, display, config, 12329, 0) + " EGL_LUMINANCE_SIZE=" + findConfigAttrib(egl, display, config, 12349, 0) + " EGL_MAX_PBUFFER_WIDTH=" + findConfigAttrib(egl, display, config, 12332, 0) + " EGL_MAX_PBUFFER_HEIGHT=" + findConfigAttrib(egl, display, config, 12330, 0) + " EGL_MAX_PBUFFER_PIXELS=" + findConfigAttrib(egl, display, config, 12331, 0) + " EGL_MAX_PBUFFER_HEIGHT=" + findConfigAttrib(egl, display, config, 12330, 0) + " EGL_MAX_PBUFFER_HEIGHT=" + findConfigAttrib(egl, display, config, 12330, 0) + " EGL_NATIVE_RENDERABLE=" + findConfigAttrib(egl, display, config, 12333, 0) + " EGL_NATIVE_VISUAL_TYPE=" + findConfigAttrib(egl, display, config, 12335, 0) + " EGL_RENDERABLE_TYPE=" + findConfigAttrib(egl, display, config, 12352, 0) + " EGL_SAMPLE_BUFFERS=" + findConfigAttrib(egl, display, config, 12338, 0) + " EGL_SAMPLES=" + findConfigAttrib(egl, display, config, 12337, 0) + " EGL_SURFACE_TYPE=" + findConfigAttrib(egl, display, config, 12339, 0) + " EGL_TRANSPARENT_TYPE=" + findConfigAttrib(egl, display, config, 12340, 0) + " EGL_TRANSPARENT_RED_VALUE=" + findConfigAttrib(egl, display, config, 12343, 0) + " EGL_TRANSPARENT_GREEN_VALUE=" + findConfigAttrib(egl, display, config, 12342, 0) + " EGL_TRANSPARENT_BLUE_VALUE=" + findConfigAttrib(egl, display, config, 12341, 0);
    }

    private int findConfigAttrib(EGL10 egl, EGLDisplay display, EGLConfig config, int attribute, int defaultValue) {
        int[] mValue = new int[1];
        if (egl.eglGetConfigAttrib(display, config, attribute, mValue)) {
            return mValue[0];
        }
        return defaultValue;
    }

    private int generateConfigSortKey(EGL10 egl, EGLDisplay display, EGLConfig config, boolean only16Bit) {
        int caveatValue;
        int colourSize = findConfigAttrib(egl, display, config, 12320, 0);
        int depthSize = findConfigAttrib(egl, display, config, 12325, 0);
        int stencilSize = findConfigAttrib(egl, display, config, 12326, 0);
        int caveat = findConfigAttrib(egl, display, config, 12327, 0);
        int numSampleBuffers = findConfigAttrib(egl, display, config, 12338, 0);
        switch (caveat) {
            case 12344:
                caveatValue = 2;
                break;
            case 12368:
                caveatValue = 1;
                break;
            case 12369:
                caveatValue = 0;
                break;
            default:
                caveatValue = 0;
                break;
        }
        int sortKey = ((((caveatValue << 24) | ((32 - numSampleBuffers) << 18)) | (colourSize << 12)) | (depthSize << 6)) | stencilSize;
        if (!only16Bit || colourSize <= 16) {
            return sortKey;
        }
        return -1;
    }

    private boolean checkGL20Support(Context context) {
        if (VERSION.SDK_INT < 8) {
            Log.i("yoyo", "Android OS version below minimum required for GL2...");
            return false;
        }
        EGL10 egl = (EGL10) EGLContext.getEGL();
        EGLDisplay display = egl.eglGetDisplay(EGL10.EGL_DEFAULT_DISPLAY);
        egl.eglInitialize(display, new int[2]);
        int[] num_config = new int[1];
        egl.eglChooseConfig(display, new int[]{12324, 4, 12323, 4, 12322, 4, 12352, 4, 12344}, new EGLConfig[10], 10, num_config);
        egl.eglTerminate(display);
        return num_config[0] > 0;
    }

    public DemoGLSurfaceView(Context context, AttributeSet attrs) {
        super(context, attrs);
        this.m_refreshHandler = new Handler();
        this.m_refreshTick = new C01621();
        RunnerActivity.CurrentActivity.setupIniFile();
        RunnerActivity.CurrentActivity.RestrictOrientation(false, false, false, false, true);
        int useGL2 = 1;
        RunnerActivity runnerActivity = (RunnerActivity) this.m_context;
        if (RunnerActivity.mYYPrefs != null) {
            runnerActivity = (RunnerActivity) this.m_context;
            useGL2 = RunnerActivity.mYYPrefs.getBoolean("UseShaders") ? 1 : 0;
            Log.i("yoyo", "Reading GL config option...");
        }
        if (useGL2 > 0) {
            Log.i("yoyo", "Trying GL2 config...");
            if (!checkGL20Support(context)) {
                useGL2 = 0;
            }
        }
        if (useGL2 > 0) {
            useGL2 = RunnerJNILib.initGLFuncs(1);
        } else {
            useGL2 = RunnerJNILib.initGLFuncs(0);
        }
        if (useGL2 == 0) {
            m_usingGL2 = 0;
            Log.i("yoyo", "Using OpenGL ES 1 renderer");
            Log.i("yoyo", "DemoGLSurfaceView: CREATED");
            this.m_context = context;
            this.m_prev = 0;
            this.m_fpsTime = 16;
            this.mRenderer = new DemoRenderer(context);
            setEGLConfigChooser(this);
            setRenderer(this.mRenderer);
            return;
        }
        m_usingGL2 = 1;
        setEGLContextClientVersion(2);
        Log.i("yoyo", "Using OpenGL ES 2 renderer");
        Log.i("yoyo", "DemoGLSurfaceView: CREATED");
        this.m_context = context;
        this.m_prev = 0;
        this.m_fpsTime = 16;
        this.mRenderer = new DemoRendererGL2(context);
        setEGLConfigChooser(this);
        setRenderer(this.mRenderer);
    }

    private void dumpEvent(MotionEvent event) {
        String[] names = new String[]{"DOWN", "UP", "MOVE", "CANCEL", "OUTSIDE", "POINTER_DOWN", "POINTER_UP", "7?", "8?", "9?"};
        StringBuilder sb = new StringBuilder();
        int action = event.getAction();
        int actionCode = action & SettingsJsonConstants.SETTINGS_IDENTIFIER_MASK_DEFAULT;
        sb.append("event ACTION_").append(names[actionCode]);
        if (actionCode == 5 || actionCode == 6) {
            sb.append("(pid ").append(action >> 8);
            sb.append(")");
        }
        sb.append("[");
        for (int i = 0; i < event.getPointerCount(); i++) {
            sb.append("#").append(i);
            sb.append("(pid ").append(event.getPointerId(i));
            sb.append(")=").append((int) event.getX(i));
            sb.append(",").append((int) event.getY(i));
            if (i + 1 < event.getPointerCount()) {
                sb.append(";");
            }
        }
        sb.append("]");
        Log.i("yoyo", sb.toString());
    }

    public boolean onGenericMotionEvent(MotionEvent event) {
        if (RunnerActivity.mExtension != null) {
            for (int i = 0; i < RunnerActivity.mExtension.length; i++) {
                if (RunnerActivity.mExtension[i] instanceof IExtensionBase) {
                    boolean consumed = ((IExtensionBase) RunnerActivity.mExtension[i]).onGenericMotionEvent(event);
                    if (consumed) {
                        return consumed;
                    }
                }
            }
        }
        return super.onGenericMotionEvent(event);
    }

    public boolean onTouchEvent(MotionEvent event) {
        int i;
        if (RunnerActivity.mExtension != null) {
            for (i = 0; i < RunnerActivity.mExtension.length; i++) {
                if (RunnerActivity.mExtension[i] instanceof IExtensionBase) {
                    boolean consumed = ((IExtensionBase) RunnerActivity.mExtension[i]).onTouchEvent(event);
                    if (consumed) {
                        return consumed;
                    }
                }
            }
        }
        int action = event.getAction();
        int actionCode = action & SettingsJsonConstants.SETTINGS_IDENTIFIER_MASK_DEFAULT;
        for (i = 0; i < event.getPointerCount(); i++) {
            int id = event.getPointerId(i);
            if (actionCode != 5 && actionCode != 6) {
                RunnerJNILib.TouchEvent(actionCode, id, event.getX(i), event.getY(i));
            } else if (((MotionEventCompat.ACTION_POINTER_INDEX_MASK & action) >> 8) == i) {
                RunnerJNILib.TouchEvent(actionCode, id, event.getX(i), event.getY(i));
            } else {
                RunnerJNILib.TouchEvent(2, id, event.getX(i), event.getY(i));
            }
        }
        try {
            Thread.sleep(16);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        return true;
    }
}
