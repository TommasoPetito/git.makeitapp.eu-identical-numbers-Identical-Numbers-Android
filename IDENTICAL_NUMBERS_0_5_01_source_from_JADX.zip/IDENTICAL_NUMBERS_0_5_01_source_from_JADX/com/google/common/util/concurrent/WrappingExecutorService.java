package com.google.common.util.concurrent;

import com.google.common.base.Preconditions;
import com.google.common.base.Throwables;
import com.google.common.collect.ImmutableList;
import com.google.common.collect.ImmutableList.Builder;
import java.util.Collection;
import java.util.List;
import java.util.concurrent.Callable;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.TimeoutException;

abstract class WrappingExecutorService implements ExecutorService {
    private final ExecutorService delegate;

    /* renamed from: com.google.common.util.concurrent.WrappingExecutorService.1 */
    class C07221 implements Runnable {
        final /* synthetic */ Callable val$wrapped;

        C07221(Callable callable) {
            this.val$wrapped = callable;
        }

        public void run() {
            try {
                this.val$wrapped.call();
            } catch (Exception e) {
                Throwables.propagate(e);
            }
        }
    }

    protected abstract <T> Callable<T> wrapTask(Callable<T> callable);

    protected WrappingExecutorService(ExecutorService delegate) {
        this.delegate = (ExecutorService) Preconditions.checkNotNull(delegate);
    }

    protected Runnable wrapTask(Runnable command) {
        return new C07221(wrapTask(Executors.callable(command, null)));
    }

    private final <T> ImmutableList<Callable<T>> wrapTasks(Collection<? extends Callable<T>> tasks) {
        Builder<Callable<T>> builder = ImmutableList.builder();
        for (Callable task : tasks) {
            builder.add(wrapTask(task));
        }
        return builder.build();
    }

    public final void execute(Runnable command) {
        this.delegate.execute(wrapTask(command));
    }

    public final <T> Future<T> submit(Callable<T> task) {
        return this.delegate.submit(wrapTask((Callable) Preconditions.checkNotNull(task)));
    }

    public final Future<?> submit(Runnable task) {
        return this.delegate.submit(wrapTask(task));
    }

    public final <T> Future<T> submit(Runnable task, T result) {
        return this.delegate.submit(wrapTask(task), result);
    }

    public final <T> List<Future<T>> invokeAll(Collection<? extends Callable<T>> tasks) throws InterruptedException {
        return this.delegate.invokeAll(wrapTasks(tasks));
    }

    public final <T> List<Future<T>> invokeAll(Collection<? extends Callable<T>> tasks, long timeout, TimeUnit unit) throws InterruptedException {
        return this.delegate.invokeAll(wrapTasks(tasks), timeout, unit);
    }

    public final <T> T invokeAny(Collection<? extends Callable<T>> tasks) throws InterruptedException, ExecutionException {
        return this.delegate.invokeAny(wrapTasks(tasks));
    }

    public final <T> T invokeAny(Collection<? extends Callable<T>> tasks, long timeout, TimeUnit unit) throws InterruptedException, ExecutionException, TimeoutException {
        return this.delegate.invokeAny(wrapTasks(tasks), timeout, unit);
    }

    public final void shutdown() {
        this.delegate.shutdown();
    }

    public final List<Runnable> shutdownNow() {
        return this.delegate.shutdownNow();
    }

    public final boolean isShutdown() {
        return this.delegate.isShutdown();
    }

    public final boolean isTerminated() {
        return this.delegate.isTerminated();
    }

    public final boolean awaitTermination(long timeout, TimeUnit unit) throws InterruptedException {
        return this.delegate.awaitTermination(timeout, unit);
    }
}
