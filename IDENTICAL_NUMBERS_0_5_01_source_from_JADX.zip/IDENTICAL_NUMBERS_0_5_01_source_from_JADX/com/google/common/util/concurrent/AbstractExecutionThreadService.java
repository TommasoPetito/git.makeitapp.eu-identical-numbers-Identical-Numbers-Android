package com.google.common.util.concurrent;

import com.google.common.annotations.Beta;
import com.google.common.base.Supplier;
import com.google.common.base.Throwables;
import com.google.common.util.concurrent.Service.Listener;
import com.google.common.util.concurrent.Service.State;
import java.util.concurrent.Executor;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.TimeoutException;
import java.util.logging.Logger;

@Beta
public abstract class AbstractExecutionThreadService implements Service {
    private static final Logger logger;
    private final Service delegate;

    /* renamed from: com.google.common.util.concurrent.AbstractExecutionThreadService.1 */
    class C06451 extends AbstractService {

        /* renamed from: com.google.common.util.concurrent.AbstractExecutionThreadService.1.1 */
        class C06431 implements Supplier<String> {
            C06431() {
            }

            public String get() {
                return AbstractExecutionThreadService.this.serviceName();
            }
        }

        /* renamed from: com.google.common.util.concurrent.AbstractExecutionThreadService.1.2 */
        class C06442 implements Runnable {
            C06442() {
            }

            public void run() {
                try {
                    AbstractExecutionThreadService.this.startUp();
                    C06451.this.notifyStarted();
                    if (C06451.this.isRunning()) {
                        AbstractExecutionThreadService.this.run();
                    }
                    AbstractExecutionThreadService.this.shutDown();
                    C06451.this.notifyStopped();
                } catch (Throwable t) {
                    C06451.this.notifyFailed(t);
                    RuntimeException propagate = Throwables.propagate(t);
                }
            }
        }

        C06451() {
        }

        protected final void doStart() {
            MoreExecutors.renamingDecorator(AbstractExecutionThreadService.this.executor(), new C06431()).execute(new C06442());
        }

        protected void doStop() {
            AbstractExecutionThreadService.this.triggerShutdown();
        }
    }

    /* renamed from: com.google.common.util.concurrent.AbstractExecutionThreadService.2 */
    class C06462 implements Executor {
        C06462() {
        }

        public void execute(Runnable command) {
            MoreExecutors.newThread(AbstractExecutionThreadService.this.serviceName(), command).start();
        }
    }

    protected abstract void run() throws Exception;

    static {
        logger = Logger.getLogger(AbstractExecutionThreadService.class.getName());
    }

    protected AbstractExecutionThreadService() {
        this.delegate = new C06451();
    }

    protected void startUp() throws Exception {
    }

    protected void shutDown() throws Exception {
    }

    protected void triggerShutdown() {
    }

    protected Executor executor() {
        return new C06462();
    }

    public String toString() {
        return serviceName() + " [" + state() + "]";
    }

    @Deprecated
    public final ListenableFuture<State> start() {
        return this.delegate.start();
    }

    @Deprecated
    public final State startAndWait() {
        return this.delegate.startAndWait();
    }

    public final boolean isRunning() {
        return this.delegate.isRunning();
    }

    public final State state() {
        return this.delegate.state();
    }

    @Deprecated
    public final ListenableFuture<State> stop() {
        return this.delegate.stop();
    }

    @Deprecated
    public final State stopAndWait() {
        return this.delegate.stopAndWait();
    }

    public final void addListener(Listener listener, Executor executor) {
        this.delegate.addListener(listener, executor);
    }

    public final Throwable failureCause() {
        return this.delegate.failureCause();
    }

    public final Service startAsync() {
        this.delegate.startAsync();
        return this;
    }

    public final Service stopAsync() {
        this.delegate.stopAsync();
        return this;
    }

    public final void awaitRunning() {
        this.delegate.awaitRunning();
    }

    public final void awaitRunning(long timeout, TimeUnit unit) throws TimeoutException {
        this.delegate.awaitRunning(timeout, unit);
    }

    public final void awaitTerminated() {
        this.delegate.awaitTerminated();
    }

    public final void awaitTerminated(long timeout, TimeUnit unit) throws TimeoutException {
        this.delegate.awaitTerminated(timeout, unit);
    }

    protected String serviceName() {
        return getClass().getSimpleName();
    }
}
