package com.google.common.html;

import com.google.common.annotations.Beta;
import com.google.common.annotations.GwtCompatible;
import com.google.common.escape.Escaper;
import com.google.common.escape.Escapers;

@GwtCompatible
@Beta
public final class HtmlEscapers {
    private static final Escaper HTML_ESCAPER;

    public static Escaper htmlEscaper() {
        return HTML_ESCAPER;
    }

    static {
        HTML_ESCAPER = Escapers.builder().addEscape('\"', "&quot;").addEscape('\'', "&#39;").addEscape('&', "&amp;").addEscape(IniSource.INCLUDE_BEGIN, "&lt;").addEscape(IniSource.INCLUDE_END, "&gt;").build();
    }

    private HtmlEscapers() {
    }
}
