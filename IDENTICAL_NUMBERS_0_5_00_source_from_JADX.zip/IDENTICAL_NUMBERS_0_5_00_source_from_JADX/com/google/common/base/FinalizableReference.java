package com.google.common.base;

public interface FinalizableReference {
    void finalizeReferent();
}
