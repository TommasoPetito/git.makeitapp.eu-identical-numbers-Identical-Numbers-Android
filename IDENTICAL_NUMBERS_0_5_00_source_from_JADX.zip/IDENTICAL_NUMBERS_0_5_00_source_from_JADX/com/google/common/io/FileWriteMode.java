package com.google.common.io;

public enum FileWriteMode {
    APPEND
}
