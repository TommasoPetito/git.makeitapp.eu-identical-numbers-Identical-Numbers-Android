package com.google.common.io;

import com.google.common.annotations.GwtCompatible;
import com.google.common.annotations.GwtIncompatible;
import com.google.common.base.Preconditions;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.Reader;
import java.io.Writer;

@GwtCompatible(emulated = true)
final class GwtWorkarounds {

    interface CharInput {
        void close() throws IOException;

        int read() throws IOException;
    }

    interface CharOutput {
        void close() throws IOException;

        void flush() throws IOException;

        void write(char c) throws IOException;
    }

    interface ByteOutput {
        void close() throws IOException;

        void flush() throws IOException;

        void write(byte b) throws IOException;
    }

    interface ByteInput {
        void close() throws IOException;

        int read() throws IOException;
    }

    /* renamed from: com.google.common.io.GwtWorkarounds.1 */
    static class C06021 implements CharInput {
        final /* synthetic */ Reader val$reader;

        C06021(Reader reader) {
            this.val$reader = reader;
        }

        public int read() throws IOException {
            return this.val$reader.read();
        }

        public void close() throws IOException {
            this.val$reader.close();
        }
    }

    /* renamed from: com.google.common.io.GwtWorkarounds.2 */
    static class C06032 implements CharInput {
        int index;
        final /* synthetic */ CharSequence val$chars;

        C06032(CharSequence charSequence) {
            this.val$chars = charSequence;
            this.index = 0;
        }

        public int read() {
            if (this.index >= this.val$chars.length()) {
                return -1;
            }
            CharSequence charSequence = this.val$chars;
            int i = this.index;
            this.index = i + 1;
            return charSequence.charAt(i);
        }

        public void close() {
            this.index = this.val$chars.length();
        }
    }

    /* renamed from: com.google.common.io.GwtWorkarounds.3 */
    static class C06043 extends InputStream {
        final /* synthetic */ ByteInput val$input;

        C06043(ByteInput byteInput) {
            this.val$input = byteInput;
        }

        public int read() throws IOException {
            return this.val$input.read();
        }

        public int read(byte[] b, int off, int len) throws IOException {
            Preconditions.checkNotNull(b);
            Preconditions.checkPositionIndexes(off, off + len, b.length);
            if (len == 0) {
                return 0;
            }
            int firstByte = read();
            if (firstByte == -1) {
                return -1;
            }
            b[off] = (byte) firstByte;
            for (int dst = 1; dst < len; dst++) {
                int readByte = read();
                if (readByte == -1) {
                    return dst;
                }
                b[off + dst] = (byte) readByte;
            }
            return len;
        }

        public void close() throws IOException {
            this.val$input.close();
        }
    }

    /* renamed from: com.google.common.io.GwtWorkarounds.4 */
    static class C06054 extends OutputStream {
        final /* synthetic */ ByteOutput val$output;

        C06054(ByteOutput byteOutput) {
            this.val$output = byteOutput;
        }

        public void write(int b) throws IOException {
            this.val$output.write((byte) b);
        }

        public void flush() throws IOException {
            this.val$output.flush();
        }

        public void close() throws IOException {
            this.val$output.close();
        }
    }

    /* renamed from: com.google.common.io.GwtWorkarounds.5 */
    static class C06065 implements CharOutput {
        final /* synthetic */ Writer val$writer;

        C06065(Writer writer) {
            this.val$writer = writer;
        }

        public void write(char c) throws IOException {
            this.val$writer.append(c);
        }

        public void flush() throws IOException {
            this.val$writer.flush();
        }

        public void close() throws IOException {
            this.val$writer.close();
        }
    }

    /* renamed from: com.google.common.io.GwtWorkarounds.6 */
    static class C06076 implements CharOutput {
        final /* synthetic */ StringBuilder val$builder;

        C06076(StringBuilder stringBuilder) {
            this.val$builder = stringBuilder;
        }

        public void write(char c) {
            this.val$builder.append(c);
        }

        public void flush() {
        }

        public void close() {
        }

        public String toString() {
            return this.val$builder.toString();
        }
    }

    private GwtWorkarounds() {
    }

    @GwtIncompatible("Reader")
    static CharInput asCharInput(Reader reader) {
        Preconditions.checkNotNull(reader);
        return new C06021(reader);
    }

    static CharInput asCharInput(CharSequence chars) {
        Preconditions.checkNotNull(chars);
        return new C06032(chars);
    }

    @GwtIncompatible("InputStream")
    static InputStream asInputStream(ByteInput input) {
        Preconditions.checkNotNull(input);
        return new C06043(input);
    }

    @GwtIncompatible("OutputStream")
    static OutputStream asOutputStream(ByteOutput output) {
        Preconditions.checkNotNull(output);
        return new C06054(output);
    }

    @GwtIncompatible("Writer")
    static CharOutput asCharOutput(Writer writer) {
        Preconditions.checkNotNull(writer);
        return new C06065(writer);
    }

    static CharOutput stringBuilderOutput(int initialSize) {
        return new C06076(new StringBuilder(initialSize));
    }
}
