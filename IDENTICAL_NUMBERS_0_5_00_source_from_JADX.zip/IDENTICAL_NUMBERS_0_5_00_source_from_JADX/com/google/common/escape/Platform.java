package com.google.common.escape;

import android.support.v4.view.accessibility.AccessibilityNodeInfoCompat;
import com.google.common.annotations.GwtCompatible;

@GwtCompatible(emulated = true)
final class Platform {
    private static final ThreadLocal<char[]> DEST_TL;

    /* renamed from: com.google.common.escape.Platform.1 */
    static class C05641 extends ThreadLocal<char[]> {
        C05641() {
        }

        protected char[] initialValue() {
            return new char[AccessibilityNodeInfoCompat.ACTION_NEXT_HTML_ELEMENT];
        }
    }

    private Platform() {
    }

    static char[] charBufferFromThreadLocal() {
        return (char[]) DEST_TL.get();
    }

    static {
        DEST_TL = new C05641();
    }
}
